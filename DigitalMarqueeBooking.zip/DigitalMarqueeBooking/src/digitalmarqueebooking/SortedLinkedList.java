/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarqueebooking;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samee
 */
public class SortedLinkedList {
    
    Node head;
    Node tail;
    SortedLinkedList(){
        head=null;
        tail=null;
    }
    
    public void InsertAscending(String u,int a,String b,String c,int d, int e, int f, int g,String h){
        Node newnode=new Node(u,a,b,c,d,e,f,g,h);
         Node temps;
        temps=head;
         boolean duplicate=false;   
            while(temps!=null){
         
            if(temps.ID==newnode.ID)
                duplicate=true;
             if(temps.next==null)
                break;
            temps=temps.next;
        } 
       
        if(duplicate!=true){
        if(head==null){
            head=newnode;
            tail=newnode;

        }
        else if(head.time>newnode.time){
                newnode.next=head;
                head=newnode;
                tail=newnode.next;
    
    }
        else{
            Node temp=head;
            int count=0;
            Node temp2;
            while(temp.next!=null){
                if(newnode.time<temp.next.time){
                    temp2=temp.next;
                    temp.next=newnode;
                    newnode.next=temp2;
                    count=1;
                    break;
                }
                if(temp.next==tail){

                    tail.next=newnode;
                    tail=newnode;
                    count=1;
                    break;
                }
               temp=temp.next; 

            }
            if(count==0){
            temp.next=newnode;
            }
        }
        }
    }
     public void inserttofile(){
        Node temp;
        temp=head;
       if (head!=null){
         
             try{
     FileWriter obj=new FileWriter("Bookings.txt",true);
                 System.out.println("writing into file");
      do {
          
          obj.write(temp.Day+"\n");
          obj.write(temp.user+"\n");
          obj.write(temp.ID+"\n");
          obj.write(temp.eventname+"\n");
          obj.write(temp.time+"\n");
          obj.write(temp.length+"\n");
          obj.write(temp.attendees+"\n");
          obj.write(temp.amount+"\n");
          obj.write(temp.status+"\n");
       
           
      
    
             if(temp.next==null)
                break;
            temp=temp.next;
        } while(temp!=null);
        obj.close();
         }catch(IOException e){
           System.out.println("FILE NOT FOUND here");
       }
       }
    }
     public void getfromfile(String a){
          try {
            File myfile=new File("Bookings.txt");
             Scanner obj=new Scanner(myfile);
         while(obj.hasNext()){
             String s=obj.nextLine();
             
             if (s.equals(a)){
                System.out.println("getting from file");
                 System.out.println("comparing "+a+" with "+s+" ");
                 
                 String day=s;
                 String user=obj.nextLine();
                 int id=Integer.parseInt(obj.nextLine());
                 System.out.println(id);
                 String name=obj.nextLine();
                 int time=Integer.parseInt(obj.nextLine());
                 int length=Integer.parseInt(obj.nextLine());
                 int attendees=Integer.parseInt(obj.nextLine());
                 int amount=Integer.parseInt(obj.nextLine());
                 String status=obj.nextLine();
                 this.InsertAscending(user,id, name, a, time, length, attendees, amount,status);
                 
                 this.display();
             }
             
         }
          }   
          catch (IllegalArgumentException e){
            System.out.println("ILLEGAL ARGUMENT"+ e);
        }catch(FileNotFoundException s){
            System.out.println("FILE NOT FOUND");
           
        }
         
         }
         public void display(){
        Node temp;
        temp=head;
             System.out.println("printing now");
       do{
         
            System.out.println(temp.ID);
             if(temp.next==null)
                break;
            temp=temp.next;
        } while(temp!=null);
        System.out.println("======== ");
    }
         public boolean checking(int timenew,int lengthnew){
              
        Node temp;
        temp=head;
            

         while(temp!=null){
             for(int i=temp.time+1;i<(temp.time+temp.length);i++){
                
                 for(int j=timenew;j<=(timenew+lengthnew);j++){
                     if(j==i){
                        return false;
                    }
                 }
             
             }
             
             temp=temp.next;
         }
         return true;
       
    }
         
         public void fileclearing(){
             
             try {
              FileWriter obj=new FileWriter("Bookings.txt",false);
             obj.write("");
             System.out.println("we here");
             obj.close();
         }
         catch(FileNotFoundException s){
            System.out.println("FILE NOT FOUND");
           
        } catch (IOException ex) {
            Logger.getLogger(SortedLinkedList.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     }
         public void statuschanger(int id,String s){
             Node temp;
        temp=head;
          
        if(temp!=null){
       do{
            if(temp.ID==id){
                System.out.println("found linked list");
                temp.status=s;
            }
            
             if(temp.next==null)
                break;
            temp=temp.next;
        } while(temp!=null);
   
         }
         }
}
    
    


