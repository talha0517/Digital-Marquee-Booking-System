/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarqueebooking;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author samee
 */
public class Stack {
    Node top;
    Stack(){
        top=null;
        
    }
    public void push(String u,int a,String b,String c,int d, int e, int f, int g,String h){
        Node newnode=new Node(u,a,b,c,d,e,f,g,h);
       
    
    
        if(top==null){
            top=newnode;
            
        }

        else{
          if(newnode.ID!=top.ID){ 
         newnode.next=top;
         top=newnode;
          }
           
        }
        }
    public void pop(){
        
        top=top.next;
    
    }
    public void inserttofile(){
      Node temp=top;
       if (temp!=null){
         
             try{
     FileWriter obj=new FileWriter("Stack.txt",false);
                 System.out.println("writing into file");
     while(temp!=null){
          
          obj.write(temp.Day+"\n");
          obj.write(temp.user+"\n");
          obj.write(temp.ID+"\n");
          obj.write(temp.eventname+"\n");
          obj.write(temp.time+"\n");
          obj.write(temp.length+"\n");
          obj.write(temp.attendees+"\n");
          obj.write(temp.amount+"\n");
          obj.write(temp.status+"\n");
       
   
            temp=temp.next;
        } 
        obj.close();
         }catch(IOException e){
           System.out.println("FILE NOT FOUND here");
       }
       }
    }
    public void add(String u,int a,String b,String c,int d, int e, int f, int g,String h){
        Node newnode=new Node(u,a,b,c,d,e,f,g,h);
       
    
        if(top==null){
            top=newnode;
            
        }

        else{
            Node temp=top;
        boolean check=false;
           while (temp.next!=null){
               
              if(newnode.ID!=temp.ID){
                  temp=temp.next;
              }
              else
              {
                  check=true;
                  break;
              }
           }
           if(check==false&&newnode.ID!=temp.ID){
           temp.next=newnode;
           }
        }
           
        }
        
     public void getfromfile(){
          try {
            File myfile=new File("Stack.txt");
             Scanner obj=new Scanner(myfile);
         while(obj.hasNext()){
             String s=obj.nextLine();
             
             
                 
                 String day=s;
                 String user=obj.nextLine();
                 int id=Integer.parseInt(obj.nextLine());
                 System.out.println(id);
                 String name=obj.nextLine();
                 int time=Integer.parseInt(obj.nextLine());
                 int length=Integer.parseInt(obj.nextLine());
                 int attendees=Integer.parseInt(obj.nextLine());
                 int amount=Integer.parseInt(obj.nextLine());
                 String status=obj.nextLine();
                 this.add(user,id, name, day, time, length, attendees, amount,status);
                 System.out.println("getting from file");
         
             
             
         }
          }   
          catch (IllegalArgumentException e){
            System.out.println("ILLEGAL ARGUMENT"+ e);
        }catch(FileNotFoundException s){
            System.out.println("FILE NOT FOUND");
           
        }
    
}
      public void statuschanger(int id,String s){
             Node temp;
        temp=top;
          
        if(temp!=null){
       do{
            if(temp.ID==id){
                System.out.println("found");
                temp.status=s;
            }
            
             if(temp.next==null)
                break;
            temp=temp.next;
        } while(temp!=null);
   
         }
         }
       public void fileclearing(){
             
             try {
              FileWriter obj=new FileWriter("Stack.txt",false);
             obj.write("");
             System.out.println("we here");
             obj.close();
         }
         catch(FileNotFoundException s){
            System.out.println("FILE NOT FOUND");
           
        } catch (IOException ex) {
            Logger.getLogger(SortedLinkedList.class.getName()).log(Level.SEVERE, null, ex);
        }
     
     }
}
