/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarqueebooking;
import java.util.Random;    
/**
 *
 * @author samee
 */
public class Node { 

    Node next;
    public static int gen() {
    Random r = new Random( System.currentTimeMillis() );
    return 10000 + r.nextInt(20000);
}
    String user;
    int ID;
    String eventname;
    String Day;
    int time;
    int length;
    int attendees;
    int amount;
    String status;

    Node(String u,int a,String b,String c,int d, int e, int f, int g,String h){
        user=u;
        ID=a;
        eventname=b;
        Day=c;
        time=d;
        length=e;
        attendees=f;
        amount=g;
        status=h;
    }
    
}
