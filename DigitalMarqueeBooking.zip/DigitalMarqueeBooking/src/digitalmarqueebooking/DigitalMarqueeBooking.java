/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitalmarqueebooking;

import java.awt.*;     

/**
 *
 * @author samee
 */
public class DigitalMarqueeBooking {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          
        Log_Sign frame1=new Log_Sign();
        Image icon = Toolkit.getDefaultToolkit().getImage("icon.png");    
        frame1.setIconImage(icon);  
        frame1.setTitle("Paradise Marquee");
        frame1.setResizable(false);
        frame1.setVisible(true);
        
    }
    }
  
